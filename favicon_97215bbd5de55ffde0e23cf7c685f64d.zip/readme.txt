
* Thank you for using our FavIcon Generator!  Here are the contents of this compressed package:

  favicon.ico  --  The favicon file (supports both 16*16 and 32*32 dimensions).

  * You can add a favicon to your web page by uploading favicon.ico to Root of your 
 website and inserting the following HTML tag between the <head> ... </head>
 tags of your web page.

<link rel="shortcut icon" href="favicon.ico">

  * How to use the Animated FavIcon: if you would like to display the animated favicon, upload
 animated_favicon1.gif also and insert the following HTML tags.

<link rel="shortcut icon" href="favicon.ico" >
<link rel="icon" href="animated_favicon1.gif" type="image/gif" >


* Other extra files in this package

  * The following files are included for your convenience. These are optional files:

 - favicon.ico - favicon.
 - preview_16x16.png - 16*16 PNG image file of the favicon.
 - preview_32x32.png - 32*32 PNG image file of the favicon.
 - animated_favicon.gif - animated version of the favicon.
 - readme.txt - this quick reference.

FreeFavicon.com